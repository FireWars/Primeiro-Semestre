import java.util.Scanner;
public class Exer4 {

  public static void main(String[] args) {
    int n=0;
    
    Scanner s = new Scanner(System.in);
    System.out.println("Informe o numero que deseja fazer a taboada: ");
    n= s.nextInt();

    System.out.println(n+" x 1 = "+ n*1);
    System.out.println(n+" x 2 = "+ n*2);
    System.out.println(n+" x 3 = "+ n*3);
    System.out.println(n+" x 4 = "+ n*4);
    System.out.println(n+" x 5 = "+ n*5);
    System.out.println(n+" x 6 = "+ n*6);
    System.out.println(n+" x 7 = "+ n*7);
    System.out.println(n+" x 8 = "+ n*8);
    System.out.println(n+" x 9 = "+ n*9);
    System.out.println(n+" x 10 = "+ n*10);
   
 }
}