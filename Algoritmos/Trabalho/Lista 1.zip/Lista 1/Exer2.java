public class Exer2 {

  public static void main(String[] args) {
    int A= 10;
    int B= 15;
    int C=0;
    C=A;
    A=B;
    B=C;
    System.out.println("Valor de A= "+A+"\nValor de B= "+B);
    }
}