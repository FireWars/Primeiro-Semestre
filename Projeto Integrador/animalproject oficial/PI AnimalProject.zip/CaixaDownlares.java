/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animalproject;

/**
 *
 * @author tiago.rbraz
 */
public class CaixaDownlares {
    public float downlares = 0;
    
    public void MensagemVitoria(){
        System.out.println("VOCÊ GANHOU 200.000 DOWNLARES!! ");
        System.out.println("PARABÉNS!! ");
    }
    
}
